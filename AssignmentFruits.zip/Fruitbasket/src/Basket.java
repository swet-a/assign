import java.io.*;
import java.util.*;

public class Basket {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		List<String> frtList = new ArrayList<>();  
		 System.out.println("Enter the fruits");
		 for(int i=0;i>=0;i++) {
		 frtList.add(sc.nextLine());
		 if(frtList.size()>5) {
			 frtList.remove(5);
			 try {
				 throw new FruitListLimitExceededException();
			 }
			 catch(FruitListLimitExceededException exp) {
				 System.out.println("No more fruits can be added");
			 }
			 break;
		 }
		 }
		 String[] array = frtList.toArray(new String[frtList.size()]);
	Mango mn=new Mango();
	mn.numMan(array);
	Apple ap=new Apple();
	ap.numAppl(array);

}
}
class FruitListLimitExceededException extends Exception{}
