
public class Apple implements Fruits {
	public void numAppl(String[] lst) {
		int cnt=0;
		for(int i=0;i<4;i++) {
			if(lst[i]=="Apple") {
				cnt+=1;
			}
		}
		System.out.println("No. of Apples are "+cnt);
	}
	public void numMan(String[] lst) {}

}
