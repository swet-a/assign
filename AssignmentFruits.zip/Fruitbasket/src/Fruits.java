
public interface Fruits {
	public void numMan(String[] arr);
	public void numAppl(String[] arr);

}
