
public class Mango implements Fruits {
public void numMan(String[] lst) {
	int cnt=0;
	for(int i=0;i<4;i++) {
		if(lst[i]=="Mango") {
			cnt+=1;
		}
	}
	System.out.println("No. of Mangoes are "+cnt);
}
public void numAppl(String[] lst) {}
}
