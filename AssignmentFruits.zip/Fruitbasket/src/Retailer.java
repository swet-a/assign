
public class Retailer extends Basket {

}
