import java.util.Arrays;

public class WholeSaler implements Person {
	public void per() {
		System.out.println("The people involved in this System are " +persons[1]);
	}
	public void whl(String[] lst) {
		System.out.println("The farmers who are wholesalers are "+Arrays.toString(lst));
		
	}

}

