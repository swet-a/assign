import java.util.Arrays;

public class Farmer implements Person {
public void per() {
	System.out.println("The people involved in this System are " +Arrays.toString(persons));
}
public void frm(String[] lst) {
System.out.println("The Farmers are" +Arrays.toString(lst));
}

}
