import java.util.*;
public class Farming {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		List<String> fruitList = new ArrayList<>();    
		 fruitList.add("Ravi");    
		 fruitList.add("Shyam");    
		 fruitList.add("Gaurav");    
		 fruitList.add("Pawan");
		 fruitList.add("Sridhar");    
		 fruitList.add("Latha");    
		 fruitList.add("Anandi");    
		 fruitList.add("Kavin");
		 //Converting ArrayList to Array  
		 String[] array = fruitList.toArray(new String[fruitList.size()]);
		 Farmer fm=new Farmer();
		 fm.per();
		 fm.frm(array);
		 
		 List<String> wsList = new ArrayList<>();  
		 System.out.println("Enter the wholesaler list");
		 for(int i=0;i<7;i++) {
		 wsList.add(sc.nextLine());
		 if(wsList.size()>5) {
			 wsList.remove(5);
			 try {
				 throw new FarmerListLimitExceededException();
			 }
			 catch(FarmerListLimitExceededException exp) {
				 System.out.println(exp);
			 }
			 break;
		 }
		 }
		 WholeSaler wh=new WholeSaler();
		 String[] array1=wsList.toArray(new String[wsList.size()]);
		 wh.whl(array1);

	}

}
class FarmerListLimitExceededException extends Exception{}