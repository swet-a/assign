public interface Person {
	String[] persons= {"Farmers as Direct Sellers","Farmers as Whole salers to Markets"};
    void per();
}
